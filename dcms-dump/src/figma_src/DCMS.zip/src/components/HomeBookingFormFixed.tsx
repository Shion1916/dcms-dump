'use client';

import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { mockServicesCatalog } from '@/data/mockData';
import { format } from 'date-fns';
import { CalendarIcon, CheckCircle } from 'lucide-react';
import { cn } from '@/components/ui/utils';
import { ServiceCatalogItem } from '@/types';
import { formatTimeSlotForDisplay } from '@/utils/timeUtils';

interface TimeSlot {
  startTime: string;
  endTime: string;
  available: boolean;
  conflictReason?: string;
}

interface HomeBookingFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const HomeBookingForm: React.FC<HomeBookingFormProps> = ({ 
  isOpen, 
  onClose, 
  onSuccess 
}) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    contact: '', // email or phone
    contactType: 'email' as 'email' | 'phone',
    service: '',
    date: undefined as Date | undefined,
    timeSlot: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [availableSlots, setAvailableSlots] = useState<TimeSlot[]>([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [selectedService, setSelectedService] = useState<ServiceCatalogItem | null>(null);

  // Fetch available slots when service and date are selected
  useEffect(() => {
    if (selectedService && formData.date) {
      fetchAvailableSlots();
    } else {
      setAvailableSlots([]);
    }
  }, [selectedService, formData.date]);

  const fetchAvailableSlots = async () => {
    if (!selectedService || !formData.date) return;

    setLoadingSlots(true);
    try {
      const response = await fetch('/api/appointments/available-slots', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          date: format(formData.date, 'yyyy-MM-dd'),
          serviceDuration: selectedService.estimated_duration,
          bufferTime: selectedService.buffer_time
        })
      });

      if (response.ok) {
        const data = await response.json();
        setAvailableSlots(data.slots || []);
      } else {
        console.error('Failed to fetch available slots');
        setAvailableSlots([]);
      }
    } catch (error) {
      console.error('Error fetching available slots:', error);
      setAvailableSlots([]);
    } finally {
      setLoadingSlots(false);
    }
  };

  const handleServiceChange = (serviceName: string) => {
    const service = mockServicesCatalog.find(s => s.name === serviceName);
    setSelectedService(service || null);
    setFormData(prev => ({ 
      ...prev, 
      service: serviceName,
      timeSlot: '' // Reset time slot when service changes
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Find the selected time slot details
      const selectedSlot = availableSlots.find(slot => 
        `${slot.startTime}-${slot.endTime}` === formData.timeSlot
      );

      // Prepare appointment data for Supabase
      const appointmentData = {
        patientName: `${formData.firstName} ${formData.lastName}`,
        patientEmail: formData.contactType === 'email' ? formData.contact : '',
        patientPhone: formData.contactType === 'phone' ? formData.contact : '',
        reason: formData.service || 'General appointment',
        requestedDate: formData.date ? format(formData.date, 'yyyy-MM-dd') : '',
        requestedTimeSlot: formData.timeSlot,
        serviceDuration: selectedService?.estimated_duration || 60,
        bufferTime: selectedService?.buffer_time || 15,
        serviceDetails: selectedService ? {
          id: selectedService.id,
          name: selectedService.name,
          description: selectedService.description,
          duration: selectedService.estimated_duration,
          buffer: selectedService.buffer_time
        } : null,
        needsStaffConfirmation: true,
        type: 'smart_booking_request'
      };

      // Submit booking through our API
      const response = await fetch('/api/appointments/book', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(appointmentData)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to submit appointment');
      }

      setIsSubmitting(false);
      setShowSuccess(true);
      
      // Reset form and close after success
      setTimeout(() => {
        setShowSuccess(false);
        setFormData({
          firstName: '',
          lastName: '',
          contact: '',
          contactType: 'email',
          service: '',
          date: undefined,
          timeSlot: ''
        });
        setSelectedService(null);
        onSuccess();
      }, 2000);
    } catch (error) {
      console.error('Error submitting appointment:', error);
      setIsSubmitting(false);
      alert('Failed to submit appointment. Please try again or call us directly.');
    }
  };

  // Always show the form now (removed isOpen check)

  if (showSuccess) {
    return (
      <div className="w-full max-w-lg mx-auto">
        <Card className="border-green-200 bg-green-50 shadow-lg">
          <CardContent className="pt-6 text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-3 text-green-800">Booking Submitted!</h3>
            <p className="text-green-700 mb-4">
              We'll contact you within 24 hours to confirm your appointment.
            </p>
            <p className="text-sm text-green-600">
              You can also call us directly at <strong>(555) 123-DENTAL</strong> for immediate assistance.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="w-full max-w-lg mx-auto">
      <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader className="pb-4">
          <div className="text-center">
            <CardTitle className="text-2xl">Book Your Appointment</CardTitle>
            <CardDescription className="text-lg">Fill out the form below and we'll get back to you soon</CardDescription>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name</Label>
                <Input
                  id="firstName"
                  placeholder="John"
                  value={formData.firstName}
                  onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  placeholder="Smith"
                  value={formData.lastName}
                  onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="contact">Contact Information</Label>
              <div className="flex space-x-2">
                <Select 
                  value={formData.contactType} 
                  onValueChange={(value: 'email' | 'phone') => setFormData(prev => ({ ...prev, contactType: value }))}
                >
                  <SelectTrigger className="w-24">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="email">Email</SelectItem>
                    <SelectItem value="phone">Phone</SelectItem>
                  </SelectContent>
                </Select>
                <Input
                  className="flex-1"
                  placeholder={formData.contactType === 'email' ? 'john@example.com' : '(555) 123-4567'}
                  type={formData.contactType === 'email' ? 'email' : 'tel'}
                  value={formData.contact}
                  onChange={(e) => setFormData(prev => ({ ...prev, contact: e.target.value }))}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="service">Service Needed *</Label>
              <Select value={formData.service} onValueChange={handleServiceChange} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select a service" />
                </SelectTrigger>
                <SelectContent>
                  {mockServicesCatalog.map((service) => (
                    <SelectItem key={service.id} value={service.name}>
                      {service.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Preferred Date *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !formData.date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.date ? format(formData.date, "MMM dd, yyyy") : "Pick date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={formData.date}
                    onSelect={(date) => setFormData(prev => ({ ...prev, date, timeSlot: '' }))}
                    disabled={(date) => date < new Date()}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label htmlFor="timeSlot">Available Time Slots *</Label>
              {!selectedService || !formData.date ? (
                <div className="text-sm text-gray-500 p-3 bg-gray-50 rounded-md">
                  Please select a service and date first to see available time slots.
                </div>
              ) : loadingSlots ? (
                <div className="text-sm text-gray-500 p-3 bg-gray-50 rounded-md flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                  Checking availability...
                </div>
              ) : availableSlots.filter(slot => slot.available).length === 0 ? (
                <div className="text-sm text-red-600 p-3 bg-red-50 rounded-md">
                  No available slots for this date. Please try another date or call us directly.
                </div>
              ) : (
                <Select 
                  value={formData.timeSlot} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, timeSlot: value }))}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select an available time slot" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableSlots
                      .filter(slot => slot.available)
                      .map((slot) => (
                      <SelectItem key={`${slot.startTime}-${slot.endTime}`} value={`${slot.startTime}-${slot.endTime}`}>
                        {formatTimeSlotForDisplay(`${slot.startTime}-${slot.endTime}`)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>

            <Button 
              type="submit" 
              className="w-full text-lg py-3" 
              size="lg" 
              disabled={isSubmitting || !formData.service || !formData.date || !formData.timeSlot}
            >
              {isSubmitting ? 'Submitting...' : 'Request Appointment'}
            </Button>
            
            <div className="text-center text-sm text-gray-600 mt-4">
              <p>Or call us directly at <strong>(555) 123-DENTAL</strong></p>
              <p>We're available Mon-Fri 8AM-6PM, Sat 9AM-4PM</p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};